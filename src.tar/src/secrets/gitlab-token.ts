import { Secret } from 'aws-cdk-lib/aws-secretsmanager';
import { Construct } from 'constructs';

class GitLabToken extends Construct {
  readonly token: Secret;

  constructor(scope: Construct, id: string) {
    super(scope, id);

    this.token = new Secret(this, 'GitLabToken');
  }
}
