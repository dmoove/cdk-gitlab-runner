import { App, Stack } from 'aws-cdk-lib';
import { Key } from 'aws-cdk-lib/aws-kms';
import { GitLabCacheBucket } from '../cache/cache-bucket';
import { GitLabConfig } from '../config-generator/config-generator';

const app = new App();

const stack = new Stack(app, 'GitLabConfig', {
  env: {
    region: 'us-east-1',
  },
});

const config = new GitLabConfig({
  concurrent: 2,
  gitlabToken: 'token',
  gitlabUrl: 'https://gitlab.com',
});

const key = new Key(stack, 'key');

const cacheBucket = new GitLabCacheBucket(stack, 'cacheBucket', {
  encryptionKey: key,
});

config.addDockerExecutor({
  disable_cache: false,
  gitlabImage: 'gitlab/gitlab-ce:latest',
  privileged: true,
});
config.addCache(stack, cacheBucket);
config.addEnvironment('TEST', 'test');

console.log(config.generateToml());

// write an unit test for the code above
test('GitLabConfig', () => {
  expect(config).toBeDefined();
});
