import { Duration, RemovalPolicy, Stack } from 'aws-cdk-lib';
import { Key } from 'aws-cdk-lib/aws-kms';
import { Bucket } from 'aws-cdk-lib/aws-s3';
import { Construct } from 'constructs';

export interface GitLabCacheBucketProps {
  /**
   * bucketNamePrefix, so that it can follow your naming scheme
   *
   * @default - {account}-{region}-gitlab-cache
   */
  bucketNamePrefix?: string;

  /**
   * bucket encryption?
   *
   * @default - key for the gitlab runner stack
   */
  encryptionKey: Key;

  /**
   * How many days the objects should be cached
   *
   * @default - 7
   */
  cacheDuration?: Duration;
}

export class GitLabCacheBucket extends Construct {
  readonly bucket: Bucket;

  constructor(scope: Construct, id: string, props: GitLabCacheBucketProps) {
    super(scope, id);

    this.bucket = new Bucket(this, 'GitLabCacheBucket', {
      autoDeleteObjects: true,
      bucketName: props.bucketNamePrefix
        ? `${props.bucketNamePrefix}-gitlab-cache`
        : `${Stack.of(this).account}-${Stack.of(this).region}-gitlab-cache`,
      encryptionKey: props.encryptionKey,
      removalPolicy: RemovalPolicy.DESTROY,
      enforceSSL: true,
    });

    this.bucket.addLifecycleRule({
      expiration: props.cacheDuration ?? Duration.days(7),
    });
  }
}
