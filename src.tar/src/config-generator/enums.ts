export enum GitlabExecutor {
  DOCKER = 'docker',
  KUBERNETES = 'kubernetes',
}
