import { Key } from 'aws-cdk-lib/aws-kms';
import { Construct } from 'constructs';
import { GitLabCacheBucket } from '../cache/cache-bucket';
import { GitLabConfig } from '../config-generator/config-generator';
import { GitlabExecutor } from '../config-generator/enums';
import { Duration } from 'aws-cdk-lib';

interface GitLabRunnerProps {
  /**
   * which encryption key to use
   *
   * @default - customer key per gitlab runner instance
   */
  encryptionKey?: Key;

  /**
   * basic runner configuration
   */
  runnerConfig: RunnerConfig;
}

interface RunnerConfig {
  /**
   * How many jobs can run concurrently
   *
   * @default - 2
   */
  concurrent?: number;
  /**
   * The token that the runner uses to authenticate with GitLab.
   */
  token: string;
  /**
   * The url of the gitlab instance.
   *
   * @default - https://gitlab.com/
   */
  url?: string;
}

class GitLabRunner extends Construct {
  readonly encryptionKey: Key;
  readonly glConfig: GitLabConfig;

  constructor(scope: Construct, id: string, props: GitLabRunnerProps) {
    super(scope, id);

    this.glConfig = new GitLabConfig({
      concurrent: props.runnerConfig.concurrent ?? 2,
      gitlabToken: 'asdasdsd',
      gitlabUrl: props.runnerConfig.url ?? 'https://gitlab.com/',
    });

    this.encryptionKey =
      props.encryptionKey ?? new Key(this, 'GitLabRunnerKey');
  }

  addCache(bucketPrefix?: string, cacheDuration?: Duration) {
    const cacheBucket = new GitLabCacheBucket(this, 'GitLabCacheBucket', {
      encryptionKey: this.encryptionKey,
      bucketNamePrefix: bucketPrefix,
      cacheDuration: cacheDuration,
    });

    this.glConfig.addCache(this, cacheBucket);
  }
}
